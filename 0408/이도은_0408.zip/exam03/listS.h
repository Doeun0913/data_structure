#pragma once
#define MAX 10

int insertElement(int L[], int n, int x);
int deleteElement(int L[], int n, int x);